package com.spring.bookcart.model;


import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Entity
@Table(name="CATEGORY")
@Component
public class Category {

	@Id
	@Column(name="CT_ID")
	private int ct_id;
	private String name;
	private String ct_desc;
	
	public int getCt_id() {
		return ct_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCt_id(int ct_id) {
		this.ct_id = ct_id;
	}
	
	public String getCt_desc() {
		return ct_desc;
	}
	public void setCt_desc(String ct_desc) {
		this.ct_desc = ct_desc;
	}
	
	
}
	