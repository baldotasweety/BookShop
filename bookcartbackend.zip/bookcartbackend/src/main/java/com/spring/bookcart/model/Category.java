package com.spring.bookcart.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Entity
@Table(name="CATEGORY")
@Component
public class Category {

	private int id;
	private String name;
	private String ct_desc;
	private int sup_id;
	
	@Id
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCt_desc() {
		return ct_desc;
	}
	public void setCt_desc(String ct_desc) {
		this.ct_desc = ct_desc;
	}
	public int getSup_id() {
		return sup_id;
	}
	public void setSup_id(int sup_id) {
		this.sup_id = sup_id;
	}
	
}
	