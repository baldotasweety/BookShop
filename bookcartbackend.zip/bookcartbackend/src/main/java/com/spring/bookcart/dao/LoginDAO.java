package com.spring.bookcart.dao;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("loginDAO")
public class LoginDAO {
	
	@Transactional
	public boolean isValid(String username, String password)
	{
		if(username.equals("sweety")&& password.equals("hello123"))
		{
			return true;
		}
		else
		{
			return false;
		}
			
	}

}
