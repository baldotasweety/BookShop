package com.spring.bookcart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "product")
@Component
public class Product {

	@Id
	@Column(name="ID")
	private int  id;
	private String name;
	private String description;
	private double price;
	@ManyToOne
    @JoinColumn(name="sup_id",nullable = false, updatable = false, insertable = true)
	private Supplier supplier;
	
	@ManyToOne
    @JoinColumn(name="ct_id",nullable = false, updatable = false, insertable = true)
   	private Category category;
	
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	
	/*public int getCt_id() {
		return ct_id;
	}
	public void setCt_id(int category_id) {
		this.ct_id = category_id;
	}
	

	public int getSup_id() {
		return sup_id;
	}
	public void setSup_id(int supplier_id) {
		this.sup_id = supplier_id;
	}

	private int ct_id;
	
	
	private int sup_id;*/

	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	

}
