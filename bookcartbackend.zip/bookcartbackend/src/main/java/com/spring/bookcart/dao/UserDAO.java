package com.spring.bookcart.dao;

import java.util.List;

import com.spring.bookcart.model.User;
import com.spring.bookcart.model.UserDetails;

public interface UserDAO {

		public List<User> list();

		public User get(String id);

		public void saveOrUpdate(User user);
		
		public void saveOrUpdate(UserDetails userDetails);

		public void delete(String id);
		
		public boolean isValid(String id, String name, boolean isAdmin);


	}



