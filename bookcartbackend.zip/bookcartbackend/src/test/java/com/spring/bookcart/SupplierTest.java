package com.spring.bookcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bookcart.dao.*;
import com.spring.bookcart.model.*;

public class SupplierTest {
	
       
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.spring.bookcart");
		context.refresh();
		
		
		SupplierDAO supplierDAO = (SupplierDAO)context.getBean("supplierDAO");
			
		Supplier supplier = (Supplier)context.getBean("supplier");
		
		supplier.setSup_id(1514);
		supplier.setName("Ratan N Sons");
		
		
		supplierDAO.saveOrUpdate(supplier);
		
		
		
	}
	
}
