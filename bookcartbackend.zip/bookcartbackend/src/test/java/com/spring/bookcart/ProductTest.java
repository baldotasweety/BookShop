package com.spring.bookcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bookcart.dao.*;
import com.spring.bookcart.model.*;

public class ProductTest {
	
       
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.spring.bookcart");
		context.refresh();
		
		
		ProductDAO productDAO = (ProductDAO)context.getBean("productDAO");
			
		Product product = (Product)context.getBean("product");
		
		SupplierDAO supplierDAO = (SupplierDAO)context.getBean("supplierDAO");
		
		Supplier supplier = (Supplier)context.getBean("supplier");
		
		CategoryDAO categoryDAO = (CategoryDAO)context.getBean("categoryDAO");
		
		Category category = (Category)context.getBean("category");
		
		
		

		product.setId(1);
		product.setName("GK");
		product.setDescription("All GK Books");
		product.setPrice(350);
		category= categoryDAO.get(1);
		System.out.println(category.getName());
		
		product.setCategory(category);
		supplier= supplierDAO.get(1511);
		product.setSupplier(supplier);
		
		System.out.println(product.getCategory().getName()+" from product");
		
		productDAO.saveOrUpdate(product);
		
		
		
	}
	
}
