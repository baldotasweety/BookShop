package com.spring.bookcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bookcart.dao.*;
import com.spring.bookcart.model.*;

public class CategoryTest {
	
       
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.spring.bookcart");
		context.refresh();
		
		
		CategoryDAO categoryDAO = (CategoryDAO)context.getBean("categoryDAO");
			
		Category category = (Category)context.getBean("category");

		category.setCt_id(1618);
		category.setName("BedTime Stories");
		category.setCt_desc("Kids stories");
		
		categoryDAO.saveOrUpdate(category);
		
		
		
	}
	
}
