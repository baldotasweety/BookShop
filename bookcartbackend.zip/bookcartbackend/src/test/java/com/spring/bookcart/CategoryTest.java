package com.spring.bookcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bookcart.dao.*;
import com.spring.bookcart.model.*;

public class CategoryTest {
	
       
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.spring.bookcart");
		context.refresh();
		
		
		CategoryDAO categoryDAO = (CategoryDAO)context.getBean("categoryDAO");
			
		Category category = (Category)context.getBean("category");
		
		category.setId(1617);
		category.setName("Mystery");
		category.setCt_desc("All mystery books");
		category.setSup_id(1513);
		
		categoryDAO.saveOrUpdate(category);
		
		
		
	}
	
}
